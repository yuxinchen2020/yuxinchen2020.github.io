%Prox function of c*phi at x 
function F = prox(y,x,cprime)

F = cprime*exp(y)/(1+exp(y))-x+y;


%% Example of the projected power method (PPM) under the random corruption model (RCM)
% The PPM algorithm is presented in the paper
% ``The Projected Power Method: An Efficient Algorithm for Joint Alignment from Pairwise Differences'' by Y. Chen and E. J. Cand�s.

%% Set parameters
param.n             = 500;     % number of variables
param.m             = 10;      % number of states 
param.p_obs         = 1;       % observation ratio
param.maxIter       = 50;      % maximum number of projected power iterations
param.mu0           = 10;      % scale factor
param.pi0           = 0.1;     % non-corruption rate
param.round_flag    = 'no';    % indicate whether mu0 is infinity
param.max_poweriter = 20;      % maximum number of power iterations
param.eps_power     = 0.02;    % tolerance level of power methods

% Noise density for the random corruption model
P0          = (1-param.pi0)* ones( param.m, 1) / param.m; 
P0(1)       = P0(1) + param.pi0;
param.P0    = P0;        
display(sprintf('n=%d, m=%d, corruption_rate=%f', param.n, param.m, 1-param.pi0))

%% Generate a synthetic example

Problem     = ProblemGenerator(param);
L           = Problem.L;        % Input log-likelihood matrix
Lambda      = eigs( L, 2);      % Compute 2nd largest eigenvalue of L
L_opt       = @(I) L  * I;      % Matrix-vector multiplication operator
proj        = @(z) ProjectOperator(z, param.n, param.m, param.mu0/Lambda(2)); % Projection operator
 
%% Run projected power method
[z, relErrors]  = noncvxAlign(param, Problem.X_gt, L_opt, proj);  % z is the output and relErrors is the L2 error
MCR             = (relErrors(end))^2 / 2/ param.n;  % misclassification rate

display(sprintf('Misclassification rate: %f', MCR))
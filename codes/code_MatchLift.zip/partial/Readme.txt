Sample codes for MatchLift presented in the paper:

Y. Chen, L. Guibas, and Q. Huang, “Near-Optimal Joint Object Matching via Convex Relaxation,” International Conference on Machine Learning (ICML), Beijing, June 2014.

Code Written by Q. Huang

toy_example.m:		An example on how to use ADMM to solve an synthetic example
problem_generator2:   	Generator of synthetic examples (w/ parameters specified in our ICML paper)
partial_map_admm_2.m : 	ADMM code  (for larger-scale problems)
partial_map_cvx.m :	CVX  (for smaller-scale problems)


You can find slides at:  www.stanford.edu/~yxchen/slides/matching_slides.pdf

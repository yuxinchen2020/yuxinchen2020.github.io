%%% Code for computing equation solutions fo rthe logistic. April 13/2017. For
%%% the paper 

%% Logistic link function and supporting functions.
phi=@(x) log(1+exp(x));
psi=@(x) exp(x)./(1+exp(x));
psiprime=@(x) exp(x)./((1+exp(x)).^2);
gauss=@(x) exp(-x.^2/2)./sqrt(2*pi);
options = optimset('Display','off');

%% Generating r, c values for a range of kappas for logistic case. 

kappa_vec= [0.495, 0.499];
% Things we would like to store are : kappa, function value, r, c ,
% rescaling constant
% norm values 
a=length(kappa_vec);
Table_1 = zeros(a,6);
x0=[3,5];
options = optimset('Display','iter','TolFun',1e-15);
for i =1:a
    tic
    disp(i)
    [x,fval] = fsolve(@(x) myequations(x,kappa_vec(i)),x0,options);
    Table_1(i,:) = [kappa_vec(i),fval(1),fval(2),x(1),x(2),x(1)^2/x(2)];
    toc
end

%% Must save the table from above. 

%%
Table_2=Table_1
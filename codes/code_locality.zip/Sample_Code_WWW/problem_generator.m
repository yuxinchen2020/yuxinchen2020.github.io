%%  The Spectral-Expanding and Spectral-Stitching algorithms are presented in the ICML 2016 paper
%  ``Community Recovery in Graphs with Locality'' by Y. Chen, G. Kamath, C. Suh, and D. Tse.
%  Code is written by G. Kamath and Y. Chen. 
%
%
%%  Generate a problem instance
%   n:                  number of vertices
%   theta:              error rate per parity read
%   beta:               exponent of the locality radius; 
%                       specifically, we let r = 0.5* n^beta
%   sample_size_const:  sample size divided by information limit
%
%   X:  ground truth
%   Y:  sample matrix
%   r:  locality radius of a ring

function [X,Y,r] = problem_generator( n, theta, sample_size_const, beta )

    X = 1 - 2* randi([0, 1], n, 1);   % Generate the ground truth
    r = round( (n^beta)/2 );          % Locality radius r of a ring graph
    
    IT_limit_const = 0.5 / (1- exp( -  0.5* log(0.5/theta) - 0.5* log(0.5/ (1-theta))));    % Preconstant of the information limit      
    num_samples    = uint32( sample_size_const * IT_limit_const * ceil(n* log(n)) );            % actual sample size

%     % First row of the adjacency matrix of the measurement graph
%     if n - 1 - 2*r > 0
%         one_row=[0, ones(1,r), zeros(1,n-2*r-1), ones(1,r)];
%     else
%         one_row=[0, ones(1,n-1)];
%     end    
%     one_row = sparse(one_row);
%     
%     adj_mat = sparse(n,n);  % adjacency matrix of the measurement graph
%     adj_mat(1,:)= one_row;

    % Generate the sample matrix Y
    Y = get_parity_samples( X, num_samples, theta, r );
%Given a choice of c, r and a grid t, this computes the prox values at
%respective points. 
function y=prox_compute_one(c,r,t)
options = optimset('Display','off');

y=zeros(1,length(t));
for i=1:length(t)
        %disp(i)
     x=r*t(i);
     f=@(y)prox(y,x,c);
     x0=0;
     y(i)=fsolve(f,x0,options);
 end
 %Computing prox for second part
 
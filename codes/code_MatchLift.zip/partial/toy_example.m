n = 50;  % # objects
m = 10;   % # points on each object
p_set = 0.8;  % observation ratio
p_error = 0.4;  % input error (the ratio of observations being corrupted)

% Parameters for ADMM
Para.nIterations = 1000; 
Para.mu_init = 0.1; 
Para.rho = 1.008

% Run MatchLift
OPT = problem_generator2(n,m,p_set,p_error); % OPT.X_gt is the ground truth
% X is the recovered object; e is the recovery error 
[X, e] = partial_map_admm_2(OPT, Para);      
%% Synthetic examples using the Spectral-Expanding and Spectral-Stitching algorithms 
%  These two algorithms are presented in the ICML'2016 paper
%  ``Community Recovery in Graphs with Locality'' by Yuxin Chen, Govinda Kamath, Changho Suh, and David Tse.
%  Code is written by Govinda Kamath and Yuxin Chen. 
%
%
%% Parameters
n     = 10000;              % number of vertices
theta = 0.1;                % error rate per parity read
beta  = 0.5;                % exponent of the locality radius; 
                            % specifically, we let r = 0.5* n^beta
sample_size_const = 1.2;    % sample size divided by information limit

% Generate a problem instance
[X, Y, r] = problem_generator( n, theta, sample_size_const, beta );

%%  Run Spectral-Expanding algorithm
X_est_SE = spectral_expanding(Y, r, n);
    
% Check correctness (up to global phase)
if abs(X_est_SE' * X) == n
    display('Spectral-expanding succeeds!')    
else
    display('Spectral-expanding fails!')
end

%%  Run Spectral-Stitching algorithm
X_est_SS = spectral_stitching(Y, r, n);
    
% Check correctness (up to global phase)
if abs(X_est_SS' * X) == n
    display('Spectral-stitching succeeds!')    
else
    display('Spectral-stitching fails!')
end

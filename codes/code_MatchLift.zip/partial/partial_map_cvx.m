% Code Written by Q. Huang

% Implementation of the MatchLift algorithm presented in the paper
% "Near-Optimal Joint Object Matching via Convex Relaxation"
% by Y. Chen, L. Guibas, and Q. Huang

function [X] = partial_map_cvx(OPT)

dim = size(OPT.W, 1);

A_eq = OPT.A(1:OPT.offset,:);
b_eq = OPT.b(1:OPT.offset);

A_neq = OPT.A((1+OPT.offset):size(OPT.A,1), :);
b_neq = OPT.b((1+OPT.offset):size(OPT.A,1));

C = ones(dim, dim) - 2*OPT.W;

cvx_begin
variable X(dim, dim);
X == semidefinite(dim);
minimize sum(sum(C.*X));
subject to
A_eq*reshape(X, [dim*dim,1]) == b_eq;
A_neq*reshape(X, [dim*dim,1]) <= b_neq;
X >= 0;
cvx_end

X = (X + X')/2;
h = 10;
%%Defining the two equations as a bivariate system of equations.
function F = myequations_probit(x,kappa)%% x is a vector, x(1) is considered tau, and x(2) is considered b.
psi=@(x) normpdf(x)./normcdf(-x);
psi_prime=@(x) (-x.*normcdf(-x).*normpdf(x)+normpdf(x).^2)./(normcdf(-x).^2);
gauss=@(y) exp(-y.^2/2)./sqrt(2*pi);
grid_gap=0.01;
t=-10:grid_gap:10;
F=[1-kappa-grid_gap*sum((1./(1+x(2).*psi_prime(prox_compute_probit(x(2),x(1),t)))).*gauss(t)); kappa*x(1)^2/(x(2)^2)-grid_gap*sum((psi(prox_compute_probit(x(2),x(1),t))).^2.*gauss(t))];

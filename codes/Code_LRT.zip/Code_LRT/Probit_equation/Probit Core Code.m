%% Logistic link function and supporting functions.
phi=@(x) -log(normcdf(-x));
psi=@(x) normpdf(x)./normcdf(-x);
psiprime=@(x) (-x.*normcdf(-x).*normpdf(x)+normpdf(x).^2)./(normcdf(-x).^2);
gauss=@(x) exp(-x.^2/2)./sqrt(2*pi);
options = optimset('Display','off');

%% Generating r, c values for a range of kappas for logistic case. 

kappa_vec= 0.1:0.01:0.4
% Things we would like to store are : kappa, function value, r, c ,
% rescaling constant
% norm values 
a=length(kappa_vec);
Table_1 = zeros(a,6);
x0=[1,1]
options = optimset('Display','iter','TolFun',1e-15);
for i =1:a
    tic
    disp(i)
    [x,fval] = fsolve(@(x) myequations_probit(x,kappa_vec(i)),x0,options);
    Table_1(i,:) = [kappa_vec(i),fval(1),fval(2),x(1),x(2),x(1)^2/x(2)];
    toc
    disp(Table_1(i,:))
end



% Run Spectral-Expanding algorithm
%   Y:              sample matrix we generate
%   r:              locality radius of a ring
%   n:              number of vertices
%
%   X_est:          estimate returned by Spectral-Expanding

function X_est = spectral_expanding(Y, r, n)
    
    % Run spectral method on a core subgraph (induced by first r vertices)
    [U, Lambda] = eigs( Y(1:r, 1:r), 1 );
    U( U>0 ) = 1;  U( U<=0 ) = -1;
    X_est_current = [U; zeros(n-r,1)];
    
    % Progressive estimation of remaining vertices via local majority vote
    for i = (r+1): n 
       if  Y( i, (i-r): (i-1)) * X_est_current( (i-r): (i-1)) >= 0
           X_est_current(i) = 1;
       else 
           X_est_current(i) = -1; 
       end
    end
    
    X_est = zeros( n, 1 );
    max_iter = 10;    % maximum number of iterations
    
    % Clean up all remaining errors by iteratively running majority voting
    for iter = 1: max_iter
        % iter
        for i = 1: n
            idx_lb = max([1, i-r]);
            idx_ub = min([n, i+r]);
            % Majority vote
            if  Y( i, idx_lb: idx_ub) * X_est_current( idx_lb: idx_ub) >= 0
                X_est(i) = 1;
            else 
                X_est(i) = -1; 
            end
        end
        
        % check whether the iterates have converged or not
        if abs(X_est' * X_est_current) == n
            break
        end
        
        X_est_current = X_est;
    end

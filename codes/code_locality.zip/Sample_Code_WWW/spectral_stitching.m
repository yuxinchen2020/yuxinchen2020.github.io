% Run Spectral-Stitching algorithm
%   Y:              sample matrix we generate
%   r:              locality radius of a ring
%   n:              number of vertices
%
%   X_est:          estimate returned by Spectral-Expanding

function X_est = spectral_stitching(Y, r, n)
        
    % Run spectral method on the first core subgraph (induced by first r vertices)
    [U, Lambda] = eigs( Y(1:r,1:r), 1 );
    U( U>0 ) = 1;  U( U<=0 ) = -1;
    X_est_current = [U; zeros(n-r,1)];

    % Split all vertices into overlapping subgroups of size r, where the
    % overlap length is chosen to be r/2; 
    % Run spectral method on each subgroup, and then stitch the estimates
    % together by checking correlation between adjacent subgroups
    for i = 1: floor(2*n/r)-2
        vertex_set = i*r/2+1 : i*r/2+r;
        [U, Lambda] = eigs( Y( vertex_set, vertex_set ), 1);
        U( U>0 ) = 1; U( U<=0 ) = -1;
        if X_est_current( i*r/2+1 : (i+1)*r/2 )' * U(1 : r/2) < 0
            U = -U;
        end
        X_est_current( (i+1)*r/2+1 : (i+2)*r/2) = U(r/2+1 : r);
    end
    
    % Deal with the last group
    [U, Lambda] = eigs( Y(end-r+1:end, end-r+1:end), 1);
    len_last_overlap    = floor(2*n/r) * r / 2 - (n-r);
    len_last_extension  = r - len_last_overlap;
    if X_est_current( end-r+1 : floor(2*n/r) * r/2)' * U(1:len_last_overlap) < 0
        U = -U;
    end
    X_est_current( end-len_last_extension+1 : end) = U(end-len_last_extension+1 : end);
    
    X_est = zeros( n, 1 );
    max_iter = 10;    % maximum number of iterations
    
    % Clean up all remaining errors by iteratively running majority voting
    for iter = 1: max_iter
        % iter
        for i = 1: n
            idx_lb = max([1, i-r]);
            idx_ub = min([n, i+r]);
            % Majority vote
            if  Y( i, idx_lb: idx_ub) * X_est_current( idx_lb: idx_ub) >= 0
                X_est(i) = 1;
            else 
                X_est(i) = -1; 
            end
        end
        
        % check whether the iterates have converged or not
        if abs(X_est' * X_est_current) == n
            break
        end
        
        X_est_current = X_est;
    end

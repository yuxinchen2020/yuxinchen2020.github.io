% Obtain parity samples (or mate-pair reads) 
%   X:              ground truth
%   num_samples:    sample size
%   theta:          error rate per parity read
%   r:              locality radius of a ring
%
%   Y:              sample matrix we generate

function Y  = get_parity_samples( X, num_samples, theta, r )
    
    n = length(X);
    
    % Generate random parity samples;
    % Each parity sample involves two vertices and the parity of their
    % corresponding parity value;
    
    vertices1           = randi([0 n-1], 1, num_samples);       % Generate the first vertex 
    gap_list            = [1:r, (-r):(-1)];                     % All feasible distances between two vertices for a ring graph
    gap_btw_vertices    = datasample( gap_list, num_samples);   % Generate the distance between two vertices
    
    temp_noise          = rand(1,num_samples);                  
    noise               = 1 - 2*( temp_noise >= 1-theta );      % Generate the read errors
    
    % Generate the parity samples; 
    % Here: Y_list(1) is the 1st vertex, Y_list(2) the 2nd vertex, and
    % Y_list(3) is the (noisy) parity read
    Y_list = [vertices1' + ones(num_samples,1), ...
              mod(vertices1' + gap_btw_vertices', n) + ones(num_samples,1), ...
              zeros(num_samples, 1)];
    
    for index = 1 : num_samples        
        arow = Y_list(index,:);
        Y_list(index,3) = X( arow(1) ) * X( arow(2) ) * noise(index);
    end
    
    Y = sparse( Y_list(:,1), Y_list(:,2), Y_list(:,3), n, n ); 
    Y = Y + Y';     % make sure the sample matrix is symmetric
end


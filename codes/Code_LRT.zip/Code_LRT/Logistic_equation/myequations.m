%%Defining the two equations as a bivariate system of equations for the
%%logistic
function F = myequations(x,kappa)%% x is a vector, x(1) is considered tau, and x(2) is considered b.
psi=@(y) exp(y)./(1+exp(y));
psi_prime=@(y) exp(y)./((1+exp(y)).^2);
gauss=@(y) exp(-y.^2/2)./sqrt(2*pi);
grid_gap=0.01;
t=-5:grid_gap:5;
F=[1-kappa-grid_gap*sum((1./(1+x(2).*psi_prime(prox_compute_one(x(2),x(1),t)))).*gauss(t)); kappa*x(1)^2/(x(2)^2)-grid_gap*sum((psi(prox_compute_one(x(2),x(1),t))).^2.*gauss(t))];
